.\.venv\Scripts\Activate.ps1
python main.py
Read-Host "Press Enter to continue"