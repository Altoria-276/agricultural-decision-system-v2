from .filepath import get_temp_image_path
